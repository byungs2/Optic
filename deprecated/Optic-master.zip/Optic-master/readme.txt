GObject
  OpticCollisionObject /* TODO need change to derivable */

  OpticObject /* TODO need change to derivable */
    OpticSpace 
    OpticPoint 
    OpticVector 
