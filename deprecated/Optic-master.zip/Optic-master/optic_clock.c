#include "include/optic_clock.h"

G_DEFINE_TYPE (OpticClock, optic_clock, OPTIC_TYPE_OBJECT)

static void
optic_clock_class_init (OpticClockClass *klass)
{

}

static void
optic_clock_init (OpticClock *instance) 
{

}
