#include "include/optic_main_loop.h"

G_DEFINE_TYPE (OpticMainLoop, optic_main_loop, OPTIC_TYPE_OBJECT)

static void
optic_main_loop_class_init (OpticMainLoopClass *klass)
{

}

static void
optic_main_loop_init (OpticMainLoop *self)
{

}
